import React, { useState, useEffect } from 'react';
import { X, DollarSign, Calendar, User, Percent, CheckCircle, Share2, Instagram, ArrowRight, ShieldCheck } from 'lucide-react';
import { ClientProfile, SaleContract, Language } from '../../types';

interface NovaVendaModalProps {
  isOpen: boolean;
  onClose: () => void;
  clients: ClientProfile[];
  onAddSale: (contract: SaleContract) => void;
  language: Language;
}

// Utilitário para calcular a data final do contrato
export const calculateContractEndDate = (
  startDateStr: string,
  installmentsCount: number,
  frequency: 'Diario' | 'Semanal Cuota Fija' | 'Quincenal' | 'Mensual'
): string => {
  if (!startDateStr || installmentsCount <= 0) return '';
  const parts = startDateStr.split('-');
  if (parts.length !== 3) return '';
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);
  const date = new Date(year, month, day);

  if (frequency === 'Diario') {
    // Pula domingos até somar as parcelas
    let counted = 0;
    while (counted < installmentsCount) {
      date.setDate(date.getDate() + 1);
      // 0 = Domingo
      if (date.getDay() !== 0) {
        counted++;
      }
    }
  } else if (frequency === 'Semanal Cuota Fija') {
    date.setDate(date.getDate() + installmentsCount * 7);
  } else if (frequency === 'Quincenal') {
    date.setDate(date.getDate() + installmentsCount * 14);
  } else if (frequency === 'Mensual') {
    date.setMonth(date.getMonth() + installmentsCount);
  }

  return date.toLocaleDateString('pt-BR');
};

export const NovaVendaModal: React.FC<NovaVendaModalProps> = ({
  isOpen,
  onClose,
  clients,
  onAddSale,
  language,
}) => {
  const isPt = language === 'pt';
  const todayStr = new Date().toISOString().split('T')[0];

  const [selectedClientId, setSelectedClientId] = useState(clients[0]?.id || '');
  const [amount, setAmount] = useState<number>(1000);
  const [downPayment, setDownPayment] = useState<number>(0);
  const [interestRate, setInterestRate] = useState<number>(20);
  const [installmentsCount, setInstallmentsCount] = useState<number>(24);
  const [frequency, setFrequency] = useState<'Diario' | 'Semanal Cuota Fija' | 'Quincenal' | 'Mensual'>('Diario');
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [unitId, setUnitId] = useState('ugi-1');
  const [clientInstagram, setClientInstagram] = useState('');

  const selectedClient = clients.find((c) => c.id === selectedClientId) || clients[0];

  useEffect(() => {
    if (selectedClient) {
      setClientInstagram(
        selectedClient.instagram || selectedClient.socialMedia?.instagram || ''
      );
    }
  }, [selectedClientId, selectedClient]);

  if (!isOpen) return null;

  // Calculos com entrada aplicada (Item 8 da folha)
  const financedAmount = Math.max(0, amount - downPayment);
  const finalAmount = financedAmount * (1 + interestRate / 100);
  const installmentValue = installmentsCount > 0 ? finalAmount / installmentsCount : 0;
  const calculatedEndDate = calculateContractEndDate(startDate, installmentsCount, frequency);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClient) return;

    const formattedStartDate = new Date(startDate + 'T12:00:00').toLocaleDateString('pt-BR');

    const newContract: SaleContract = {
      id: `cont-${Date.now()}`,
      saleId: `VEN-${Math.floor(10000 + Math.random() * 90000)}`,
      clientId: selectedClient.id,
      clientName: selectedClient.fullName,
      clientAlias: selectedClient.alias,
      unitId: unitId,
      unitName: unitId === 'ugi-1' ? '1 - UGI-1' : '2 - UGI-2',
      saleDate: formattedStartDate,
      amount: amount,
      downPayment: downPayment,
      interestRate: interestRate,
      finalAmount: finalAmount,
      installmentsCount: installmentsCount,
      installmentValue: installmentValue,
      paidInstallments: 0,
      pendingBalance: finalAmount,
      frequency: frequency,
      collectionDay: 'Segunda',
      firstPaymentDate: formattedStartDate,
      startDate: formattedStartDate,
      endDate: calculatedEndDate,
      clientInstagram: clientInstagram || undefined,
      status: 'Activa',
      additionalCollected: 0,
      extraCollected: 0,
    };

    onAddSale(newContract);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="bg-white rounded-2xl shadow-2xl border border-purple-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[95vh]">
        {/* Modal Header */}
        <div className="bg-[#50007d] text-white px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <DollarSign className="w-5 h-5 text-[#8cc63f]" />
            <div>
              <h3 className="font-bold text-base">
                {isPt ? 'Nova Venda / Contrato' : 'Nueva Venta / Contrato'}
              </h3>
              <p className="text-[11px] text-purple-200 font-medium">
                {isPt ? 'Com Entrada, Data Final e Redes Sociais' : 'Con Anticipo, Fecha Final y Redes'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-purple-200 hover:text-white p-1 rounded-lg hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-3.5 text-xs overflow-y-auto">
          {/* Client Selection */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#50007d]" />
              {isPt ? 'Cliente' : 'Cliente'}
            </label>
            <select
              value={selectedClientId}
              onChange={(e) => setSelectedClientId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.alias} - {c.fullName} ({c.documentType}: {c.documentNumber}) [Score: {c.score}]
                </option>
              ))}
            </select>
          </div>

          {/* Item 4: Redes Sociais no Cliente */}
          <div className="bg-purple-50/70 border border-purple-200 rounded-lg p-2.5">
            <label className="block text-purple-900 font-semibold mb-1 flex items-center gap-1.5">
              <Instagram className="w-3.5 h-3.5 text-[#E1306C]" />
              <span>{isPt ? 'Rede Social do Cliente (Instagram / WhatsApp):' : 'Red Social del Cliente:'}</span>
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <span className="absolute left-2.5 top-2.5 text-slate-400 font-semibold">@</span>
                <input
                  type="text"
                  placeholder="perfil.instagram ou link"
                  value={clientInstagram}
                  onChange={(e) => setClientInstagram(e.target.value.replace(/^@/, ''))}
                  className="w-full bg-white border border-purple-200 rounded-lg pl-7 pr-2.5 py-1.5 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
                />
              </div>
              {clientInstagram ? (
                <a
                  href={`https://instagram.com/${clientInstagram}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1.5 bg-[#E1306C] hover:bg-[#c1275d] text-white rounded-lg font-bold text-[10px] flex items-center gap-1 transition"
                >
                  <Share2 className="w-3 h-3" />
                  Ver Perfil
                </a>
              ) : null}
            </div>
          </div>

          {/* Unit Selection */}
          <div>
            <label className="block text-slate-700 font-semibold mb-1">
              {isPt ? 'Unidade de Cobrança (UGI)' : 'Unidad (UGI)'}
            </label>
            <select
              value={unitId}
              onChange={(e) => setUnitId(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
            >
              <option value="ugi-1">1 - UGI-1 (Carlos Oliveira)</option>
              <option value="ugi-2">2 - UGI-2 (Roberto Mendes)</option>
            </select>
          </div>

          {/* Item 8: Entrada e Valor Emprestado */}
          <div className="grid grid-cols-2 gap-3">
            {/* Amount Total */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                {isPt ? 'Valor Emprestado (R$)' : 'Valor Prestado'}
              </label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(Math.max(0, Number(e.target.value)))}
                min={50}
                step={50}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-bold focus:ring-1 focus:ring-[#50007d] focus:outline-none"
                required
              />
            </div>

            {/* Down Payment (Entrada) */}
            <div>
              <label className="block text-emerald-800 font-bold mb-1 flex items-center gap-1">
                <DollarSign className="w-3 h-3 text-emerald-600" />
                {isPt ? 'Entrada / Sinal (R$)' : 'Anticipo / Entrada'}
              </label>
              <input
                type="number"
                value={downPayment}
                onChange={(e) => setDownPayment(Math.max(0, Number(e.target.value)))}
                min={0}
                max={amount}
                step={20}
                className="w-full bg-emerald-50 border border-emerald-300 rounded-lg p-2.5 text-emerald-900 font-black focus:ring-1 focus:ring-emerald-600 focus:outline-none"
                placeholder="0.00"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Interest Rate */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1 flex items-center gap-1">
                <Percent className="w-3 h-3 text-[#76b82a]" />
                {isPt ? 'Taxa de Juros (%)' : 'Tasa de Interés (%)'}
              </label>
              <input
                type="number"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                min={0}
                max={100}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-bold focus:ring-1 focus:ring-[#50007d] focus:outline-none"
                required
              />
            </div>

            {/* Installments Count */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                {isPt ? 'Quantidade de Parcelas' : 'Número de Cuotas'}
              </label>
              <input
                type="number"
                value={installmentsCount}
                onChange={(e) => setInstallmentsCount(Math.max(1, Number(e.target.value)))}
                min={1}
                max={360}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {/* Frequency */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">
                {isPt ? 'Frequência de Pagamento' : 'Modalidad de Cobro'}
              </label>
              <select
                value={frequency}
                onChange={(e) => setFrequency(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
              >
                <option value="Diario">{isPt ? 'Diário (Seg a Sáb)' : 'Diario'}</option>
                <option value="Semanal Cuota Fija">{isPt ? 'Semanal' : 'Semanal'}</option>
                <option value="Quincenal">{isPt ? 'Quinzenal' : 'Quincenal'}</option>
                <option value="Mensual">{isPt ? 'Mensal' : 'Mensual'}</option>
              </select>
            </div>

            {/* Start Date */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-[#50007d]" />
                {isPt ? 'Data de Início' : 'Fecha Inicial'}
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-800 font-medium focus:ring-1 focus:ring-[#50007d] focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Item 8: Aplicar Data Final e Resumo com Entrada */}
          <div className="bg-[#f7f2fa] border border-purple-200 rounded-xl p-3.5 space-y-2 text-slate-700">
            {downPayment > 0 && (
              <div className="flex justify-between text-xs pb-1.5 border-b border-purple-100">
                <span className="text-slate-600">
                  {isPt ? 'Entrada Paga em Dinheiro:' : 'Anticipo Pagado:'}
                </span>
                <span className="font-bold text-emerald-600 font-mono">
                  - R$ {downPayment.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
              </div>
            )}

            <div className="flex justify-between text-xs pb-1.5 border-b border-purple-100">
              <span className="text-slate-600">
                {isPt ? 'Saldo Base Financiado:' : 'Base Financiada:'}
              </span>
              <span className="font-bold text-slate-800 font-mono">
                R$ {financedAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-semibold">{isPt ? 'Total a Cobrar:' : 'Total a Cobrar:'}</span>
              <span className="font-extrabold text-[#50007d] font-mono text-base">
                R$ {finalAmount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-semibold">{isPt ? 'Valor da Parcela:' : 'Valor de Cuota:'}</span>
              <span className="font-extrabold text-[#76b82a] font-mono text-base">
                R$ {installmentValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </span>
            </div>

            {/* Linha da Data Final Calculada */}
            <div className="pt-1.5 border-t border-purple-200 flex justify-between items-center bg-purple-100/60 -mx-3.5 -mb-3.5 p-2.5 rounded-b-xl">
              <div className="flex items-center gap-1.5 text-purple-900 font-bold">
                <Calendar className="w-3.5 h-3.5 text-[#50007d]" />
                <span>{isPt ? 'Data Final Prevista:' : 'Fecha Final Estimada:'}</span>
              </div>
              <div className="font-extrabold font-mono text-[#50007d] text-sm flex items-center gap-1">
                <ArrowRight className="w-3.5 h-3.5 text-[#76b82a]" />
                {calculatedEndDate}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-700 font-semibold transition"
            >
              {isPt ? 'Cancelar' : 'Cancelar'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-lg bg-[#76b82a] hover:bg-[#68a722] text-white font-bold transition flex items-center space-x-1.5 shadow-sm"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isPt ? 'Criar Contrato' : 'Crear Contrato'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
