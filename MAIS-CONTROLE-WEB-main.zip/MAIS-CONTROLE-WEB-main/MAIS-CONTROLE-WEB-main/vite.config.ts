import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import crypto from 'crypto';
import { defineConfig, Plugin } from 'vite';

// Dev middleware plugin para prover /api/v1 e WebSocket /realtime durante desenvolvimento local
function maisControleDevApiPlugin(): Plugin {
  return {
    name: 'mais-controle-dev-api',
    configureServer(server) {
      const devSales: any[] = [];
      const devCashflow: any[] = [];
      const devClients: any[] = [
        { id: '1003161', name: 'Anielo Gomes Corvino', alias: 'Du Surf', creditLimit: 5000 },
        { id: '1003177', name: 'Levson Levson', alias: 'Matrix', creditLimit: 10000 },
        { id: '1003185', name: 'Carlos Alberto Prado', alias: 'Beto Auto Peças', creditLimit: 3000 },
      ];
      const devSockets = new Set<any>();

      const broadcast = (type: string, payload: any) => {
        const msg = JSON.stringify({ type, payload, timestamp: Date.now() });
        const messageBuf = Buffer.from(msg, 'utf-8');
        const len = messageBuf.length;
        const header = len < 126
          ? Buffer.from([0x81, len])
          : Buffer.concat([Buffer.from([0x81, 126]), Buffer.from([len >> 8, len & 0xff])]);
        const frame = Buffer.concat([header, messageBuf]);

        for (const s of devSockets) {
          try {
            if (s && !s.destroyed && s.writable) {
              s.write(frame);
            } else {
              devSockets.delete(s);
            }
          } catch (e) {
            devSockets.delete(s);
          }
        }
      };

      server.middlewares.use((req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader(
          'Access-Control-Allow-Headers',
          'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Unit-ID, X-Register-ID'
        );
        if (req.method === 'OPTIONS') {
          res.statusCode = 200;
          res.end();
          return;
        }

        if (req.url?.startsWith('/api/v1/auth/pin-login') && req.method === 'POST') {
          let body = '';
          req.on('data', (c) => {
            body += c;
          });
          req.on('end', () => {
            const data = body ? JSON.parse(body) : {};
            res.setHeader('Content-Type', 'application/json');
            res.end(
              JSON.stringify({
                success: true,
                token: Buffer.from(
                  JSON.stringify({
                    unitId: data.unitId || '15',
                    registerId: data.registerId || '1002325',
                  })
                ).toString('base64'),
                unit: { unitId: data.unitId || '15', registerId: data.registerId || '1002325' },
              })
            );
          });
          return;
        }

        if (req.url?.startsWith('/api/v1/sales')) {
          if (req.method === 'GET') {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(devSales));
            return;
          }
          if (req.method === 'POST') {
            let body = '';
            req.on('data', (c) => {
              body += c;
            });
            req.on('end', () => {
              const data = body ? JSON.parse(body) : {};
              if (req.url?.includes('batch-sync')) {
                const list = data.sales || [];
                devSales.unshift(...list);
                list.forEach((s) => broadcast('SALE_CREATED', s));
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ success: true, count: list.length }));
              } else {
                devSales.unshift(data);
                broadcast('SALE_CREATED', data);
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify(data));
              }
            });
            return;
          }
        }

        if (req.url?.startsWith('/api/v1/cashflow')) {
          if (req.method === 'GET') {
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify(devCashflow));
            return;
          }
          if (req.method === 'POST') {
            let body = '';
            req.on('data', (c) => {
              body += c;
            });
            req.on('end', () => {
              const data = body ? JSON.parse(body) : {};
              if (req.url?.includes('batch-sync')) {
                const list = data.movements || [];
                devCashflow.unshift(...list);
                list.forEach((m) => broadcast('CASHFLOW_UPDATED', m));
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify({ success: true, count: list.length }));
              } else {
                devCashflow.unshift(data);
                broadcast('CASHFLOW_UPDATED', data);
                res.setHeader('Content-Type', 'application/json');
                res.end(JSON.stringify(data));
              }
            });
            return;
          }
        }

        if (req.url?.startsWith('/api/v1/clients') && req.method === 'GET') {
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(devClients));
          return;
        }

        next();
      });

      server.httpServer?.on('upgrade', (req, socket) => {
        const url = new URL(req.url || '/', 'http://localhost');
        if (url.pathname === '/realtime') {
          const wsKey = req.headers['sec-websocket-key'];
          if (!wsKey) {
            socket.destroy();
            return;
          }
          const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
          const acceptKey = crypto.createHash('sha1').update(wsKey + GUID).digest('base64');
          socket.write(
            [
              'HTTP/1.1 101 Switching Protocols',
              'Upgrade: websocket',
              'Connection: Upgrade',
              `Sec-WebSocket-Accept: ${acceptKey}`,
              '\r\n',
            ].join('\r\n')
          );

          devSockets.add(socket);
          socket.on('close', () => devSockets.delete(socket));
          socket.on('error', () => devSockets.delete(socket));
        }
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), maisControleDevApiPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      hmr: process.env.DISABLE_HMR !== 'true',
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
