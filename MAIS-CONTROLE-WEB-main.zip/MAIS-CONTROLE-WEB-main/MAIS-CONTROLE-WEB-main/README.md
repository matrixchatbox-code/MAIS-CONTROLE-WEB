# 🖥️ MAIS CONTROLE - CENTRAL WEB DE CONTROLE E GESTÃO ADMINISTRATIVA

Painel web central e servidor de integração em tempo real para o ecossistema **Mais Controle**.

Responsável pelo monitoramento gerencial de Unidades de Negócio (UGIs), rastreamento GPS de cobradores em rota, aprovações financeiras, fluxo de caixa unificado, controle de permissões por IMEI e hub de comunicação bidirecional com os terminais móveis dos trabalhadores.

---

## 🚀 Ambientes e Conexões Oficiais

* **Painel Web Central**: [https://mais-controle.ai.studio/](https://mais-controle.ai.studio/)
* **API REST**: `https://mais-controle.ai.studio/api/v1`
* **WebSocket Pulse**: `wss://mais-controle.ai.studio/realtime`
* **App Trabalhador Conectado**: [https://mais-controle-trabalhador.ai.studio/](https://mais-controle-trabalhador.ai.studio/)
* **Google Cloud Project**: `gen-lang-client-0781059800` (Região: `us-east1`)
* **Repositório GitHub**: `https://github.com/matrixchatbox-code/MAIS-CONTROLE-WEB.git`

---

## 🛠️ Arquitetura e Módulos do Sistema

1. **Servidor Híbrido REST & WebSocket (`server.ts`)**:
   - Desenvolvido em Node.js com Express e WebSocket RFC 6455 nativo (compatibilidade direta no Google Cloud Run sem dependências externas adicionais).
   - Mecanismo de Heartbeat (Ping 25s) para manter conexões ativas mesmo sob proxies e load balancers.
   - Rotas de autenticação por PIN, listagem/gravação de vendas, lotes offline (`batch-sync`) e comandos de segurança (`devices/command`).
2. **Sincronização em Tempo Real (`src/utils/realtimeWebSync.ts`)**:
   - Conecta a tela do administrador diretamente ao hub WebSocket.
   - Quando um cobrador recebe um pagamento em campo, o contrato e a entrada no caixa são exibidos instantaneamente na tela do gestor.
3. **Indicador Visual de Conectividade (`TryTopNavigation.tsx`)**:
   - Badge dinâmico **Pulse Ativo 🟢** e contadores de aprovações pendentes.
4. **Segurança e Gestão de Dispositivos (`TryAdministracionView.tsx`)**:
   - Bloqueio remoto imediato de aparelhos (Trava IMEI) e formatação remota (Wipe).
5. **Suíte de Testes Automatizada (`scripts/test-realtime-connection.mjs`)**:
   - Validação dos 8 fluxos principais de comunicação entre app móvel e central web.

---

## 💻 Executando Localmente

### 1. Modo Desenvolvimento (Vite com Mock de API e WebSocket Embutidos)
```bash
npm install
npm run dev
```
Acesse em: `http://localhost:3000`

### 2. Modo Servidor de Produção (Cloud Run Local)
```bash
npm run build
npm start
```

### 3. Teste da Conexão em Tempo Real
```bash
node scripts/test-realtime-connection.mjs
```

---

## 📦 Envio para o GitHub

```bash
git init
git remote add origin https://github.com/matrixchatbox-code/MAIS-CONTROLE-WEB.git
git add .
git commit -m "feat: implementacao do servidor pulse, api rest e sincronizacao web"
git branch -M main
git push -u origin main --force
```
