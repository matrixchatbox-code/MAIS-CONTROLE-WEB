/**
 * Script de Teste e Validacao da Conexao:
 * MAIS CONTROLE TRABALHADOR <-> MAIS CONTROLE WEB
 * 
 * Executa validacao de:
 * 1. Health Check da API Central
 * 2. Autenticacao de PIN (The Vault)
 * 3. Consulta de Clientes (1003161 Du Surf, 1003177 Matrix)
 * 4. Registro de Venda Online
 * 5. Batch Sync de Vendas Offline
 * 6. Registro de Fluxo de Caixa (Sangria / Suprimento / Inflow)
 * 7. Envio de Telemetria GPS em Rota
 * 8. Comando de Bloqueio/Desbloqueio Remoto IMEI
 */

const BASE_URL = process.env.CENTRAL_URL || 'http://localhost:3000';

async function runTests() {
  console.log('========================================================');
  console.log(`[TESTE] Conectando ao Servidor Central: ${BASE_URL}`);
  console.log('========================================================\n');

  try {
    // 1. Health Check
    console.log('1. Testando /api/health...');
    const healthRes = await fetch(`${BASE_URL}/api/health`);
    const healthData = await healthRes.json();
    console.log('   Status:', healthRes.status, healthData);

    // 2. PIN Login (The Vault)
    console.log('\n2. Testando login por PIN (Unidade 15 / Caixa 1002325)...');
    const authRes = await fetch(`${BASE_URL}/api/v1/auth/pin-login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ pin: '0000', unitId: '15', registerId: '1002325' }),
    });
    const authData = await authRes.json();
    console.log('   Auth Sucesso:', authData.success);
    console.log('   Token Gerado:', authData.token?.substring(0, 30) + '...');

    const token = authData.token;

    // 3. Consulta de Clientes
    console.log('\n3. Testando consulta de clientes da UGI 15...');
    const clientsRes = await fetch(`${BASE_URL}/api/v1/clients`);
    const clientsData = await clientsRes.json();
    console.log(`   Clientes encontrados (${clientsData.length}):`, clientsData.map((c) => `${c.id} - ${c.name} (${c.alias})`));

    // 4. Venda Online
    console.log('\n4. Testando gravacao de venda online...');
    const saleRes = await fetch(`${BASE_URL}/api/v1/sales`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'X-Unit-ID': '15',
        'X-Register-ID': '1002325',
      },
      body: JSON.stringify({
        clientId: '1003161',
        clientName: 'Du Surf (Anielo Corvino)',
        amount: 120,
        paymentMethod: 'PIX',
        items: [{ productId: 'p1', name: 'Parcela 1/10', quantity: 1, price: 120 }],
        unitId: '15',
        registerId: '1002325',
      }),
    });
    const saleData = await saleRes.json();
    console.log('   Venda Registrada:', saleData.id, `- R$ ${saleData.amount} (${saleData.paymentMethod})`);

    // 5. Batch Sync Offline
    console.log('\n5. Testando sincronizacao em lote da fila offline...');
    const batchRes = await fetch(`${BASE_URL}/api/v1/sales/batch-sync`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'X-Unit-ID': '15',
        'X-Register-ID': '1002325',
      },
      body: JSON.stringify({
        sales: [
          {
            id: `offline_sale_${Date.now()}_1`,
            clientId: '1003177',
            clientName: 'Matrix (Levson Levson)',
            amount: 240,
            paymentMethod: 'CASH',
            items: [{ productId: 'p2', name: 'Parcela 2/29', quantity: 1, price: 240 }],
            unitId: '15',
            registerId: '1002325',
            timestamp: new Date().toISOString(),
          },
        ],
      }),
    });
    const batchData = await batchRes.json();
    console.log('   Batch Sync Concluido:', batchData);

    // 6. Fluxo de Caixa
    console.log('\n6. Testando movimentacao de caixa (Sangria/Entrada)...');
    const cashRes = await fetch(`${BASE_URL}/api/v1/cashflow`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'X-Unit-ID': '15',
        'X-Register-ID': '1002325',
      },
      body: JSON.stringify({
        type: 'INFLOW',
        amount: 120,
        description: 'Venda PDV - PIX Du Surf',
        unitId: '15',
        registerId: '1002325',
      }),
    });
    const cashData = await cashRes.json();
    console.log('   Movimento de Caixa:', cashData.id, `- ${cashData.type} R$ ${cashData.amount}`);

    // 7. Telemetria GPS
    console.log('\n7. Testando envio de telemetria GPS...');
    const gpsRes = await fetch(`${BASE_URL}/api/v1/telemetry/location`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        workerId: 'carlos_oliveira',
        unitId: '15',
        latitude: -23.4628,
        longitude: -46.5333,
        speed: 18.5,
        battery: 94,
      }),
    });
    const gpsData = await gpsRes.json();
    console.log('   GPS Transmitido:', gpsData.location);

    // 8. Comando Remoto de Dispositivo
    console.log('\n8. Testando comando de bloqueio remoto IMEI...');
    const cmdRes = await fetch(`${BASE_URL}/api/v1/devices/command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        deviceId: 'dev-1',
        command: 'LOCK',
        reason: 'Teste de seguranca da Central Web',
      }),
    });
    const cmdData = await cmdRes.json();
    console.log('   Comando Remoto Emitido:', cmdData.command);

    console.log('\n========================================================');
    console.log('✅ TODOS OS TESTES DE INTEGRACAO PASSARAM COM SUCESSO!');
    console.log('========================================================');
  } catch (err) {
    console.error('❌ Falha ao executar testes de integracao:', err.message);
  }
}

runTests();
