// Realtime WebSocket Synchronization Engine for MAIS CONTROLE WEB
// Recebe vendas e movimentacoes de caixa originadas no aplicativo do trabalhador
import { useEffect, useRef, useState, useCallback } from 'react';
import { StorageService } from './storage';
import { SaleContract, CashMovement } from '../types';

export const getRealtimeWsUrl = (): string => {
  if (typeof window !== 'undefined') {
    // Se estiver rodando em producao no Cloud Run ou AI Studio
    if (window.location.hostname.includes('ai.studio') || window.location.hostname.includes('run.app')) {
      return `wss://${window.location.host}/realtime`;
    }
    // Desenvolvimento local
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}/realtime`;
  }
  return 'wss://mais-controle.ai.studio/realtime';
};

export interface WebRealtimeState {
  isConnected: boolean;
  lastEventTime: number | null;
  lastEventName: string | null;
}

export function useWebRealtimeSync(
  onSaleReceived?: (sale: any) => void,
  onMovementReceived?: (movement: any) => void
) {
  const [status, setStatus] = useState<WebRealtimeState>({
    isConnected: false,
    lastEventTime: null,
    lastEventName: null,
  });

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<any>(null);

  const connect = useCallback(() => {
    try {
      const wsUrl = `${getRealtimeWsUrl()}?clientType=web_dashboard&unitId=15&registerId=1002325`;
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        setStatus((prev) => ({ ...prev, isConnected: true }));
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setStatus((prev) => ({
            ...prev,
            lastEventTime: Date.now(),
            lastEventName: data.type || 'UNKNOWN',
          }));

          if (data.type === 'SALE_CREATED' && data.payload) {
            const rawSale = data.payload;
            const newContract: SaleContract = {
              id: rawSale.id || `contract-${Date.now()}`,
              saleId: rawSale.id?.replace('sale_', '') || `${Date.now()}`,
              unitId: rawSale.unitId || '15',
              unitName: `UGI ${rawSale.unitId || '15'}`,
              collectorName: 'Carlos Oliveira',
              clientId: rawSale.clientId || 'avulso',
              clientName: rawSale.clientName || 'Cliente Consumidor',
              clientAlias: rawSale.clientName?.split(' ')[0] || 'Cliente',
              saleDate: new Date(rawSale.timestamp || Date.now()).toLocaleDateString('pt-BR'),
              totalAmount: rawSale.amount || 120,
              installmentValue: rawSale.amount || 120,
              installmentsCount: 1,
              paidInstallments: 1,
              pendingBalance: 0,
              frequency: 'Diário',
              status: 'Al día',
              paymentMethod: rawSale.paymentMethod === 'PIX' ? 'Transferencia' : 'Efectivo',
            };

            const existing = StorageService.getContracts();
            if (!existing.some((c) => c.id === newContract.id || c.saleId === newContract.saleId)) {
              StorageService.setContracts([newContract, ...existing]);
            }

            if (onSaleReceived) {
              onSaleReceived(newContract);
            }
          } else if (data.type === 'CASHFLOW_UPDATED' && data.payload) {
            const raw = data.payload;
            const newMovement: CashMovement = {
              id: raw.id || `mov-${Date.now()}`,
              unitId: raw.unitId || '15',
              unitName: `UGI ${raw.unitId || '15'}`,
              workerName: 'Carlos Oliveira',
              date: new Date(raw.timestamp || Date.now()).toISOString().split('T')[0],
              type: raw.type === 'OUTFLOW' || raw.type === 'SANGRIA' ? 'Egreso' : 'Ingreso',
              category: raw.type === 'SUPRIMENTO' ? 'Aporte de Capital' : 'Cobro Diario',
              description: raw.description || 'Movimentação via App Trabalhador',
              comments: `Registrado em tempo real via Pulse: R$ ${raw.amount}`,
              value: raw.amount || 0,
              paymentMethod: 'Transferencia',
              approved: true,
            };

            const existing = StorageService.getMovements();
            if (!existing.some((m) => m.id === newMovement.id)) {
              StorageService.setMovements([newMovement, ...existing]);
            }

            if (onMovementReceived) {
              onMovementReceived(newMovement);
            }
          }
        } catch (e) {
          // Ignora mensagens malformadas
        }
      };

      ws.onclose = () => {
        setStatus((prev) => ({ ...prev, isConnected: false }));
        reconnectTimeoutRef.current = setTimeout(() => {
          connect();
        }, 5000);
      };

      ws.onerror = () => {
        ws.close();
      };

      wsRef.current = ws;
    } catch (err) {
      setStatus((prev) => ({ ...prev, isConnected: false }));
      reconnectTimeoutRef.current = setTimeout(() => {
        connect();
      }, 5000);
    }
  }, [onSaleReceived, onMovementReceived]);

  useEffect(() => {
    connect();
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [connect]);

  return status;
}
