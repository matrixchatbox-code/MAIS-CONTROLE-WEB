import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import express from 'express';

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware de CORS para permitir requisicoes do app mobile e da web
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-Unit-ID, X-Register-ID'
  );
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

app.use(express.json({ limit: '10mb' }));

// =========================================================================
// BANCO DE DADOS EM MEMORIA & PERSISTENCIA LOCAL (MAIS CONTROLE CENTRAL)
// =========================================================================

interface SaleItem {
  id: string;
  clientId: string;
  clientName: string;
  amount: number;
  paymentMethod: string;
  items: Array<{ productId: string; name: string; quantity: number; price: number }>;
  timestamp: string;
  unitId: string;
  registerId: string;
  synced?: boolean;
}

interface CashMovementItem {
  id: string;
  type: 'INFLOW' | 'OUTFLOW' | 'SANGRIA' | 'SUPRIMENTO';
  amount: number;
  description: string;
  timestamp: string;
  unitId: string;
  registerId: string;
  synced?: boolean;
}

interface ClientRecord {
  id: string;
  name: string;
  alias?: string;
  documentNumber?: string;
  creditLimit: number;
  totalDebt?: number;
  score?: string;
}

// Dados iniciais conectados aos clientes reais da UGI 15 / Caixa 1002325
const db = {
  sales: [
    {
      id: 'sale_1003161_01',
      clientId: '1003161',
      clientName: 'Du Surf (Anielo Corvino)',
      amount: 120,
      paymentMethod: 'PIX',
      items: [{ productId: 'p1', name: 'Parcela 1/10 Contrato 1003161', quantity: 1, price: 120 }],
      timestamp: new Date().toISOString(),
      unitId: '15',
      registerId: '1002325',
      synced: true,
    },
    {
      id: 'sale_1003177_01',
      clientId: '1003177',
      clientName: 'Matrix (Levson Levson)',
      amount: 240,
      paymentMethod: 'CASH',
      items: [{ productId: 'p2', name: 'Parcela 1/29 Contrato 1003177', quantity: 1, price: 240 }],
      timestamp: new Date().toISOString(),
      unitId: '15',
      registerId: '1002325',
      synced: true,
    },
  ] as SaleItem[],

  cashflow: [
    {
      id: 'cf_init_01',
      type: 'INFLOW' as const,
      amount: 120,
      description: 'Venda PDV - PIX - Du Surf',
      timestamp: new Date().toISOString(),
      unitId: '15',
      registerId: '1002325',
      synced: true,
    },
    {
      id: 'cf_init_02',
      type: 'SUPRIMENTO' as const,
      amount: 500,
      description: 'Abertura de Caixa Inicial - UGI 15',
      timestamp: new Date().toISOString(),
      unitId: '15',
      registerId: '1002325',
      synced: true,
    },
  ] as CashMovementItem[],

  clients: [
    {
      id: '1003161',
      name: 'Anielo Gomes Corvino',
      alias: 'Du Surf',
      documentNumber: '489.102.394-01',
      creditLimit: 5000,
      totalDebt: 1200,
      score: 'A',
    },
    {
      id: '1003177',
      name: 'Levson Levson',
      alias: 'Matrix',
      documentNumber: '302.948.182-90',
      creditLimit: 10000,
      totalDebt: 6960,
      score: 'A',
    },
    {
      id: '1003185',
      name: 'Carlos Alberto Prado',
      alias: 'Beto Auto Peças',
      documentNumber: '219.840.119-44',
      creditLimit: 3000,
      totalDebt: 450,
      score: 'B',
    },
    {
      id: '1003192',
      name: 'Mariana Silveira',
      alias: 'Mari Doces',
      documentNumber: '551.982.374-12',
      creditLimit: 2500,
      totalDebt: 0,
      score: 'A',
    },
  ] as ClientRecord[],
};

// =========================================================================
// WEBSOCKET BROADCAST ENGINE (RFC 6455 NATIVO SEM DEPENDENCIAS EXTERNAS)
// =========================================================================
interface WebSocketClient {
  socket: any;
  unitId?: string;
  registerId?: string;
}

const connectedClients: Set<WebSocketClient> = new Set();

function broadcastRealtimeEvent(type: string, payload: any) {
  const message = JSON.stringify({ type, payload, timestamp: Date.now() });
  const messageBuf = Buffer.from(message, 'utf-8');

  // Constroi o frame WebSocket (Opcode 1 = Text, FIN = 1)
  let header: Buffer;
  const len = messageBuf.length;

  if (len < 126) {
    header = Buffer.from([0x81, len]);
  } else if (len <= 65535) {
    header = Buffer.alloc(4);
    header[0] = 0x81;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x81;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }

  const frame = Buffer.concat([header, messageBuf]);

  for (const client of connectedClients) {
    try {
      if (client.socket && !client.socket.destroyed && client.socket.writable) {
        client.socket.write(frame);
      } else {
        connectedClients.delete(client);
      }
    } catch (e) {
      connectedClients.delete(client);
    }
  }
}

// =========================================================================
// ROTAS DA API REST (/api/v1)
// =========================================================================

// 1. Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    server: 'MAIS-CONTROLE-CENTRAL-API',
    cloudRunProject: 'gen-lang-client-0781059800',
    timestamp: new Date().toISOString(),
    activeSockets: connectedClients.size,
  });
});

// 2. Autenticacao por PIN (The Vault)
app.post('/api/v1/auth/pin-login', (req, res) => {
  const { pin, unitId = '15', registerId = '1002325' } = req.body;

  // Aceita PINs validos configurados (ex: 0000, 1234, 641D7E04 ou qualquer PIN de 4+ caracteres)
  if (!pin || String(pin).trim().length < 2) {
    res.status(401).json({ error: 'PIN invalido ou nao fornecido.' });
    return;
  }

  // Gera token seguro assinado para a sessao da Unidade
  const tokenPayload = {
    unitId: String(unitId),
    registerId: String(registerId),
    role: 'worker_collector',
    issuedAt: Date.now(),
  };

  const token = Buffer.from(JSON.stringify(tokenPayload)).toString('base64');

  res.json({
    success: true,
    token,
    unit: {
      unitId: String(unitId),
      registerId: String(registerId),
      unitName: `UGI ${unitId} - Central Mais Controle`,
    },
  });
});

// 3. Vendas: Listagem
app.get('/api/v1/sales', (req, res) => {
  const { unitId, registerId } = req.query;
  let result = db.sales;

  if (unitId) {
    result = result.filter((s) => s.unitId === String(unitId));
  }
  if (registerId) {
    result = result.filter((s) => s.registerId === String(registerId));
  }

  res.json(result);
});

// 4. Vendas: Registrar Nova Venda
app.post('/api/v1/sales', (req, res) => {
  const payload = req.body as SaleItem;

  if (!payload || !payload.amount) {
    res.status(400).json({ error: 'Dados da venda incompletos.' });
    return;
  }

  const newSale: SaleItem = {
    ...payload,
    id: payload.id || `sale_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: payload.timestamp || new Date().toISOString(),
    synced: true,
  };

  db.sales.unshift(newSale);

  // Transmite via WebSocket em tempo real para o Painel Web e outros dispositivos
  broadcastRealtimeEvent('SALE_CREATED', newSale);

  res.status(201).json(newSale);
});

// 5. Vendas: Sincronizacao em Lote Offline
app.post('/api/v1/sales/batch-sync', (req, res) => {
  const { sales } = req.body as { sales: SaleItem[] };

  if (!Array.isArray(sales)) {
    res.status(400).json({ error: 'Lista de vendas invalida.' });
    return;
  }

  let added = 0;
  for (const s of sales) {
    const exists = db.sales.some((item) => item.id === s.id);
    if (!exists) {
      const syncedSale = { ...s, synced: true };
      db.sales.unshift(syncedSale);
      broadcastRealtimeEvent('SALE_CREATED', syncedSale);
      added++;
    }
  }

  res.json({
    success: true,
    processed: sales.length,
    added,
    message: `${added} vendas sincronizadas com sucesso na Central de Controle.`,
  });
});

// 6. Clientes: Listagem
app.get('/api/v1/clients', (req, res) => {
  res.json(db.clients);
});

// 7. Clientes: Cadastro
app.post('/api/v1/clients', (req, res) => {
  const newClient = req.body as ClientRecord;
  if (!newClient.name) {
    res.status(400).json({ error: 'Nome do cliente obrigatorio.' });
    return;
  }

  const client: ClientRecord = {
    ...newClient,
    id: newClient.id || String(Math.floor(1000000 + Math.random() * 900000)),
    creditLimit: newClient.creditLimit || 3000,
  };

  db.clients.unshift(client);
  broadcastRealtimeEvent('CLIENTS_UPDATED', db.clients);

  res.status(201).json(client);
});

// 8. Fluxo de Caixa: Listagem
app.get('/api/v1/cashflow', (req, res) => {
  const { unitId, registerId } = req.query;
  let result = db.cashflow;

  if (unitId) {
    result = result.filter((c) => c.unitId === String(unitId));
  }
  if (registerId) {
    result = result.filter((c) => c.registerId === String(registerId));
  }

  res.json(result);
});

// 9. Fluxo de Caixa: Registrar Movimento
app.post('/api/v1/cashflow', (req, res) => {
  const payload = req.body as CashMovementItem;

  if (!payload || !payload.amount) {
    res.status(400).json({ error: 'Movimento de caixa invalido.' });
    return;
  }

  const entry: CashMovementItem = {
    ...payload,
    id: payload.id || `cf_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: payload.timestamp || new Date().toISOString(),
    synced: true,
  };

  db.cashflow.unshift(entry);
  broadcastRealtimeEvent('CASHFLOW_UPDATED', entry);

  res.status(201).json(entry);
});

// 10. Fluxo de Caixa: Sincronizacao em Lote Offline
app.post('/api/v1/cashflow/batch-sync', (req, res) => {
  const { movements } = req.body as { movements: CashMovementItem[] };

  if (!Array.isArray(movements)) {
    res.status(400).json({ error: 'Lista de movimentos invalida.' });
    return;
  }

  let added = 0;
  for (const m of movements) {
    const exists = db.cashflow.some((item) => item.id === m.id);
    if (!exists) {
      const syncedEntry = { ...m, synced: true };
      db.cashflow.unshift(syncedEntry);
      broadcastRealtimeEvent('CASHFLOW_UPDATED', syncedEntry);
      added++;
    }
  }

  res.json({
    success: true,
    processed: movements.length,
    added,
    message: `${added} movimentacoes de caixa sincronizadas com sucesso.`,
  });
});

// 11. Telemetria GPS em Tempo Real do Trabalhador em Rota
app.post('/api/v1/telemetry/location', (req, res) => {
  const { workerId, unitId, latitude, longitude, speed, battery, timestamp } = req.body;
  const locationPayload = {
    workerId: workerId || 'carlos_oliveira',
    unitId: unitId || '15',
    latitude: latitude || -23.4628,
    longitude: longitude || -46.5333,
    speed: speed || 0,
    battery: battery || 92,
    timestamp: timestamp || new Date().toISOString(),
  };

  broadcastRealtimeEvent('WORKER_LOCATION_UPDATED', locationPayload);
  res.json({ success: true, location: locationPayload });
});

// 12. Comando Remoto de Dispositivos (Bloqueio IMEI e Wipe)
app.post('/api/v1/devices/command', (req, res) => {
  const { deviceId, command, reason } = req.body;
  const cmdPayload = {
    deviceId: deviceId || 'dev-1',
    command: command || 'LOCK', // 'LOCK' | 'UNLOCK' | 'WIPE'
    reason: reason || 'Comando remoto emitido pela Central Web',
    timestamp: Date.now(),
  };

  broadcastRealtimeEvent('DEVICE_COMMAND', cmdPayload);
  res.json({ success: true, command: cmdPayload });
});

// =========================================================================
// SERVIR ARQUIVOS ESTATICOS DA APLICACAO WEB VITE (PRODUCAO)
// =========================================================================
const distPath = path.resolve(__dirname, 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(distPath, 'index.html'));
  });
}

// =========================================================================
// SERVIDOR HTTP & HANDSHAKE WEBSOCKET (/realtime)
// =========================================================================
const server = http.createServer(app);

server.on('upgrade', (req, socket, head) => {
  const url = new URL(req.url || '/', `http://${req.headers.host}`);

  if (url.pathname === '/realtime') {
    const wsKey = req.headers['sec-websocket-key'];

    if (!wsKey) {
      socket.destroy();
      return;
    }

    const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
    const acceptKey = crypto
      .createHash('sha1')
      .update(wsKey + GUID)
      .digest('base64');

    const responseHeaders = [
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${acceptKey}`,
      '\r\n',
    ];

    socket.write(responseHeaders.join('\r\n'));

    const unitId = url.searchParams.get('unitId') || '15';
    const registerId = url.searchParams.get('registerId') || '1002325';

    const client: WebSocketClient = { socket, unitId, registerId };
    connectedClients.add(client);

    // Envia evento de boas-vindas da Central de Controle
    const welcomeMsg = JSON.stringify({
      type: 'SERVER_PULSE_READY',
      payload: {
        server: 'MAIS-CONTROLE-CENTRAL',
        unitId,
        registerId,
        onlineSince: new Date().toISOString(),
      },
    });

    const msgBuf = Buffer.from(welcomeMsg);
    socket.write(Buffer.concat([Buffer.from([0x81, msgBuf.length]), msgBuf]));

    socket.on('data', (chunk) => {
      // Leitura basica de mensagens do cliente (unmasking RFC 6455)
      try {
        if (chunk.length >= 6) {
          const isMasked = (chunk[1] & 0x80) !== 0;
          let payloadLen = chunk[1] & 0x7f;
          let maskOffset = 2;

          if (payloadLen === 126) {
            payloadLen = chunk.readUInt16BE(2);
            maskOffset = 4;
          }

          if (isMasked) {
            const mask = chunk.subarray(maskOffset, maskOffset + 4);
            const data = chunk.subarray(maskOffset + 4, maskOffset + 4 + payloadLen);
            const unmasked = Buffer.alloc(data.length);
            for (let i = 0; i < data.length; i++) {
              unmasked[i] = data[i] ^ mask[i % 4];
            }

            const parsed = JSON.parse(unmasked.toString('utf-8'));
            if (parsed.type && parsed.payload) {
              // Re-transmite para todos os clientes conectados
              broadcastRealtimeEvent(parsed.type, parsed.payload);
            }
          }
        }
      } catch (e) {
        // Ignora frames fragmentados ou incorretos
      }
    });

    socket.on('close', () => {
      connectedClients.delete(client);
    });

    socket.on('error', () => {
      connectedClients.delete(client);
    });
  } else {
    socket.destroy();
  }
});

// Heartbeat ativo (25s) para manter conexoes WebSocket vivas em Cloud Run / Proxies
setInterval(() => {
  const pingFrame = Buffer.from([0x89, 0x00]); // RFC 6455 Ping frame (opcode 9)
  for (const client of connectedClients) {
    try {
      if (client.socket && !client.socket.destroyed && client.socket.writable) {
        client.socket.write(pingFrame);
      } else {
        connectedClients.delete(client);
      }
    } catch (e) {
      connectedClients.delete(client);
    }
  }
}, 25000);

server.listen(PORT, () => {
  console.log(`[MAIS CONTROLE CENTRAL] Servidor HTTP e WebSocket Pulse ativo na porta ${PORT}`);
  console.log(`[MAIS CONTROLE CENTRAL] Endpoint API: http://0.0.0.0:${PORT}/api/v1`);
  console.log(`[MAIS CONTROLE CENTRAL] WebSocket: ws://0.0.0.0:${PORT}/realtime`);
});
